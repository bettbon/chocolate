package com.example.bettybongo.sqlitelab;

/**
 * Created by Betty Bongo on 24/10/2017.
 */

public class Companies {
    int comp_id;
    String comp_name;
    String comp_phone_number;

    public Companies() {

    }

    public Companies(int id, String name, String _phone_number) {
        this.comp_id = id;
        this.comp_name = name;
        this.comp_phone_number = _phone_number;
    }

    public Companies(String name, String _phone_number){
        this.comp_name = name;
        this.comp_phone_number = _phone_number;
    }

    public int getID(){
        return this.comp_id;
    }

    public void setID(int id){
        this.comp_id = id;
    }

    public String getName(){
        return this.comp_name;
    }

    public void setName(String name){
        this.comp_name = name;
    }

    public String getPhoneNumber(){
        return this.comp_phone_number;
    }

    public void setPhoneNumber(String phone_number){
        this.comp_phone_number = phone_number;
    }

}
